﻿桌宠源码包
与 GitHub 提交 7275369 的根目录 PetApp.cs 一致。

构建：
1. 解压源码包与同版本的部署包。
2. 把部署包内的 assets 目录复制到源码包解压目录。
3. 把部署包内的 NAudio.dll 复制到源码目录的 naudio110\lib\net35\NAudio.dll。
4. 在 Windows PowerShell 5.1 中运行 .\build.ps1。
5. 编译结果位于 dist，保留 EXE、NAudio.dll 和 assets 的相对位置。