﻿# Build desktop pet C# version
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (-not $root) { $root = Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $root) { $root = Get-Location }

$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Force -Path $dist | Out-Null

# Convert source to UTF-8 with BOM (csc reads ANSI without BOM -> Chinese garbled)
$src = Join-Path $root 'PetApp.cs'
$text = [IO.File]::ReadAllText($src, [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($src, $text, [Text.UTF8Encoding]::new($true))
Write-Host "Source converted to UTF-8 BOM"

# Locate csc.exe via runtime directory (robust across Framework/Framework64)
$csc = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) 'csc.exe'
if (-not (Test-Path -LiteralPath $csc)) { throw "csc not found: $csc" }
Write-Host "Using csc: $csc"

$out = Join-Path $dist 'zhuo_chong.exe'
$refs = @(
  'System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll',
  'System.Xml.dll','System.Net.dll'
) | ForEach-Object { "/r:$_" }
$naudio = Join-Path $root 'naudio110\lib\net35\NAudio.dll'
if (Test-Path -LiteralPath $naudio) { $refs += "/r:$naudio" }

& $csc /nologo /target:winexe /optimize /out:$out $refs $src
if ($LASTEXITCODE -ne 0) { Write-Host "COMPILE FAILED exit=$LASTEXITCODE"; exit 1 }
Write-Host "COMPILE OK: $out"

# Copy NAudio.dll alongside exe
if (Test-Path -LiteralPath $naudio) { Copy-Item $naudio $dist -Force; Write-Host "NAudio.dll copied" }

# Copy assets (contents, not nested folder)
$assetDst = Join-Path $dist 'assets'
New-Item -ItemType Directory -Force -Path $assetDst | Out-Null
Copy-Item (Join-Path $root 'assets\*') $assetDst -Recurse -Force
Write-Host "Assets copied"

# Rename to final Chinese name
$finalName = [char]0x684C + [char]0x5BA0 + [char]0x00B7 + [char]0x516B + [char]0x91CD + [char]0x795E + [char]0x5B50 + '.exe'
$final = Join-Path $dist $finalName
if (Test-Path -LiteralPath $final) { Remove-Item -LiteralPath $final -Force }
Rename-Item -LiteralPath $out -NewName $finalName
Write-Host "Final: $final"
Get-ChildItem $dist | Select-Object Name, Length
